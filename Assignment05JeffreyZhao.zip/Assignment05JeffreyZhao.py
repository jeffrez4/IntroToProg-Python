# ------------------------------------------------- #
# Title: Assignment 5
# Dev: Jeffrey Zhao (Original Developer: Randal Root)
# Date: October 30, 2017
# ChangeLog: (Jeffrey Zhao, 10/30/2017, Change template into executable program with given functions)
# RRoot, 11/02/2016, Created starting template
# Jeffrey Zhao, a student of Randal Root, Added code to complete assignment 5
# This program is designed to create a To-Do list and a menu for its navigation through
# which users can view and add/remove tasks and their priority levels.
# ------------------------------------------------- #

# -- Data and Variables -- #
fileName = "ToDo.txt"
firstTable = []
dictRow = {}
strMenu = """
    Menu of Options
    1) Show current data
    2) Add a new item
    3) Remove an existing item
    4) Save Data to File
    5) Exit Program
"""

# Opens text File with data #
# Reads line-by-line in text file #
# Separates data into two pairs of keys and values by splitting on the comma #
# Forms initial table that can be accessed and adjusted by the user menu(strMenu) #
readFile = open(fileName, "r") #
for lineOfFile in readFile:
    column = lineOfFile.split(",")
    dictrow = {"Task":column[0].strip(),"Priority":column[1].strip()}
    firstTable.append(dictrow)

while(True):

    # Displays a menu of choices to the user using this defined method #
    # Prompts user input to select from the menu #
    # Prints empty line for more spacing #
    print(strMenu)
    strChoice = str(input("Which option would you like to perform? [1 to 4] - "))
    print()

    # Shows the current items in the table if the user selects '1' #
    # Prints out the current table(format is as a list), line-by-line in dictionary format using a for loop #
    if (strChoice.strip() == '1'):
        for line in firstTable:
            print(line)

    # Adds a new item to the list/Table if the user selects '2' #
    # Prompts user input for new task and new priority level #
    # Appends the newly created row to the current table #
    elif(strChoice.strip() == '2'):
        inputTask = input("What is the task? (multiple words must be spaced!) ")
        inputLevel = input("What is the Priority Level? ")
        addRow = {"Task":inputTask.title(), "Priority":inputLevel.lower()}
        firstTable.append(addRow)

    # Finds and removes a new item to the list/table if the user selects '3' #
    # Prints "Task not found" if the task could not be found in the stored data #
    elif(strChoice == '3'):
        exist = False
        deleteTask = input("Name of task to delete? (multiple words must be spaced) ")
        for i in firstTable:
                if i["Task"] == deleteTask.title():
                   firstTable.remove(i)
                   print("\nRemoval has been executed!!!")
                   exist = True
        if exist is False:
            print("Task not found. Please try again")

    # Saves tasks to the txt file if the user selects '4' with a for loop #
    # Stores the "Task" and "Priority" values #
    elif(strChoice == '4'):
        writeFile = open(fileName, "w")
        for line in firstTable:
            writeFile.write(str(line["Task"]) + "," + str(line["Priority"]+"\n"))
        print("Saving has been executed!!!")
        writeFile.close()

    # Exits the program if the user selects '5' #
    elif (strChoice == '5'):
        readFile.close()
        break

    # Generates error if user does not properly input a number in 1 - 5 #
    else:
        print("Did not recognize your input. Please use numbers 1 - 5 to navigate the menu")