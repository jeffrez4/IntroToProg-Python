# ------------------------------------------------- #
# Title: Assignment 6 TO DO LIST WITH CLASS, FUNCTIONS, AND OBJECT-ORIENTED PROGRAMMING
# Dev: Jeffrey Zhao (Original Developer: Randal Root)
# Date: November 06, 2017
# ChangeLog: (Jeffrey Zhao, 10/30/2017, Change template into executable program with given functions)
# RRoot, 11/02/2016, Created starting template
# Jeffrey Zhao, a student of Randal Root, Added code to complete Assignment 6
# This program is designed to create a To-Do list and a menu for its navigation through
# which users can view and add/remove tasks and their priority levels, using class,
# functions, and object-oriented programming
# ------------------------------------------------- #

#-- Data/Variables -- #
userMenu = """
    Menu of Options
    1) Show current data
    2) Add a new item
    3) Remove an existing item
    4) Save Data to File
    5) Exit Program
"""
masterTable = []
fileName = "ToDo.txt"
menuChoice = None

#-- Processing -- #
class programExecution(object):
    @staticmethod
    def displayMenu():
        """Displays a menu of choices to the user and prompts user input, returns menuChoice"""
        print(userMenu)
        menuChoice = str(input("Which option would you like to perform? [1 to 4] - "))
        print()
        return menuChoice

    def extractFileData(fileName):
        """When the program starts, loads any data you have in text file into a dictionary"""
        readFile = open(fileName, "r")
        for lineOfFile in readFile:
            word = lineOfFile.split(",")
            readRow = {"Task": word[0].strip(), "Priority": word[1].strip()}
            masterTable.append(readRow)
        readFile.close()

    @staticmethod
    def viewTable():
        """Shows the current items in the table"""
        for line in masterTable:
            print(line)

    @staticmethod
    def addToTable():
        """Appends a new item to the list/Table. Prompts user input for new task and new priority level"""
        newTask = input("What is the task? (multiple words must be spaced!) ").strip()
        newPriorityLevel = input("What is the Priority Level? ").strip()
        addRow = {"Task": newTask.title(), "Priority": newPriorityLevel.lower()}
        masterTable.append(addRow)
        print(addRow, "has been added!!!")

    @staticmethod
    def removeFromTable():
        """Locates and removes an item to the list/table. Produces error if task not found"""
        exist = False
        deleteTask = input("Name of task to delete? (multiple words must be spaced) ")
        for i in masterTable:
            if i["Task"] == deleteTask.title():
                masterTable.remove(i)
                print("\nRemoval has been executed!!!")
                exist = True
        if exist is False:
            print("Task not found. Please try again")

    def saveToFile(fileName):
        """Saves progress to txt file"""
        saveFile = open(fileName, "w")
        for line in masterTable:
            saveFile.write(str(line["Task"]) + "," + str(line["Priority"] + "\n"))
        print("Saving has been executed!!!")
        saveFile.close()

# -- Presentation/Output -- #
# -- Main Execution of the Program -- #
programExecution.extractFileData(fileName)
while (True):
    menuChoice = programExecution.displayMenu()
    if (menuChoice.strip() == '1'):
        programExecution.viewTable()
    elif (menuChoice.strip() == '2'):
        programExecution.addToTable()
    elif (menuChoice.strip() == '3'):
        programExecution.removeFromTable()
    elif (menuChoice.strip() == '4'):
        programExecution.saveToFile(fileName)
    elif (menuChoice.strip() == '5'):
        break
    else:
        print("Did not recognize your input. Please use numbers 1 - 5 to navigate the menu")